#adds removes and edits usernames and passwords
from cryptography.fernet import Fernet 
from os import system,name
def clear(): 
    if name == 'nt': 
        _ = system('cls')
    else: 
        _ = system('clear') 

def add (filename,app,uname,pwd):                           #function to add application and its credentials
    with open(filename,'rb') as rfb:
        key=rfb.readline()
        f=Fernet(key)
    with open(filename,'ab') as afb:
        enc_app=f.encrypt(app.encode())
        enc_uname=f.encrypt(uname.encode())
        enc_pwd=f.encrypt(pwd.encode())
        #print(type(enc_uname))
        afb.write(enc_app)
        afb.write('\n'.encode('utf-8'))
        afb.write(enc_uname)
        afb.write('\n'.encode('utf-8'))
        afb.write(enc_pwd)
        afb.write('\n'.encode('utf-8'))
        print("\t\t\tNew Entry added:\n\t\t\t",app,"\n\t\t\t",uname,"\n\t\t\t",pwd)
        input("\t\t\tPress Enter to continue")
        clear()

def change(filename,app):                                   #function to edit username and password values for any application
    clear()
    with open(filename,'ab+') as rfb:
        rfb.seek(0)
        key=rfb.readline()
        f=Fernet(key)
        i=1 
        flag=0
        for stream in rfb:
            if i%3==1 and flag==0 :
                ele=f.decrypt(stream)
                ele_s=str(ele).strip('b\'')
                if ele_s==app:
                    flag=1
                    print("\t\t\tApplication: ",app,"\n\t\t\tUsername: ",str(f.decrypt(rfb.readline())).strip('b\''),"\n\t\t\tPassword: ",str(f.decrypt(rfb.readline())).strip('b\''))
                    break
            i=i+1
        rfb.seek(0)
        data=rfb.readlines()
    new_uname=input("\t\t\tEnter new username(Press enter for no change):    ")
    new_pwd=input("\t\t\tEnter new password(Press enter for no change):  ")
    i=i+1
    if new_uname:
        enc_uname=f.encrypt(new_uname.encode())
        data[i]=enc_uname
        data[i]=data[i]+('\n'.encode('utf-8'))
    ele=f.decrypt(data[i])
    new_uname=str(ele).strip('b\'')
    i=i+1
    if new_pwd:
        enc_pwd=f.encrypt(new_pwd.encode())
        data[i]=enc_pwd
        data[i]=data[i]+('\n'.encode('utf-8'))
    ele=f.decrypt(data[i])
    new_pwd=str(ele).strip('b\'')
    with open(filename,'wb') as afb:
        afb.writelines(data)
    print("\t\t\tEntry updated:\n\t\t\tApplication: ",app,"\n\t\t\tUsername: ",new_uname,"\n\t\t\tPassword: ",new_pwd)
    input("\t\t\tPress enter to continue")
    clear()


def disp(filename):                                             #prints all the data
    clear()
    with open(filename,'rb') as rf:
        key=rf.readline()
        f=Fernet(key)
        i=1
        flag=0
        for stream in rf:
            if flag==1:
                username=f.decrypt(stream)
                print("\t\t\tUsername: ", str(username).strip('b\''))
                flag+=1
            elif flag==2:
                pwd=f.decrypt(stream)
                print("\t\t\tPassword: ", str(pwd).strip('b\'')) 
                flag=0
            if i%3==1:
                ele=f.decrypt(stream)
                ele_s=str(ele).strip('b\'')
                print("\n\t\t\tApplication: ",ele_s)
                flag=1
            i=i+1
        if i==1:
            print("\t\t\tNo entries present!!")
        input("\t\t\tPress enter to continue!")
        clear()


def search(filename,app):                                   #function to retreive credentials for a particular application
    with open(filename,'rb') as rfb:
        key=rfb.readline()
        f=Fernet(key)
        i=1 
        flag=0
        for stream in rfb:
            if flag==1:
                username=f.decrypt(stream)
                print("\t\t\tUsername: ", str(username).strip('b\''))
                flag+=1
            elif flag==2:
                pwd=f.decrypt(stream)
                print("\t\t\tPassword: ", str(pwd).strip('b\''))
                input("\t\t\tPress Enter to coninue")
                clear()
                rfb.close()
                return
            if i%3==1 and flag==0 :
                ele=f.decrypt(stream)
                ele_s=str(ele).strip('b\'')
                if ele_s==app:
                    flag=1
                    clear()
                    print("\t\t\tApplication: ",app)
            i=i+1
        rfb.close()
        print("\t\t\tNo results found!!")
        input("\t\t\tPress enter to continue")
        clear()

def research(filename,app):
    with open(filename,'rb') as rfb:
        key=rfb.readline()
        f=Fernet(key)
        i=1 
        flag=0
        for stream in rfb:
            if i%3==1 and flag==0 :
                ele=f.decrypt(stream)
                ele_s=str(ele).strip('b\'')
                if ele_s==app:
                    return(1)
            i=i+1
        return(0)