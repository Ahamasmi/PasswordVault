#login and script in python
from cryptography.fernet import Fernet
import hashlib as hl 
import random
import os
from getpass import getpass as gp
def clear(): 
    if os.name == 'nt': 
        _ = os.system('cls')
    else: 
        _ = os.system('clear')
def login():  
    clear()  
    stat=os.path.exists("databases/db.txt")
    if stat:
        user=input("\t\t\tEnter username: ")                          #takes username as input
        pwd=gp("\t\t\tEnter password: ")                              #takes password
        with open("databases/db.txt","r") as lf:                          #opens database file to confirm credentials
            i=1
            flag=0
            u_hash=hl.sha256(bytes(user,"UTF-8")).hexdigest()   #calculates hash of username
            p_hash=hl.sha256(bytes(pwd,"UTF-8")).hexdigest()    #calculates hash of pwd
            for line in lf:           
                if flag==1:                                     #if flag is set to 1 ie. prev line was username
                    if p_hash==line.strip():                    #if pwd hashes match
                        return user                             #returns username
                if u_hash==line.strip() and i%2!=0:             #if username hashes match and line number is odd
                    flag=1                                      #flag is set to 1 so that next line checks ped
                i+=1
            if i==1:
                print("\t\t\tEmpty database, sign up first!")    
                input("\t\t\tPress enter to continue")
                return("\n") 
            return ""                                           #return empty string if credentials not correct
    else:                                                       #db file does not exist
        print("\t\t\tEmpty database, sign up first!")    
        input("\t\t\tPress enter to continue")
        return("\n")             

def signup():
    clear()
    flag=1
    with open("databases/db.txt","a+") as sf:                         #opens database file
        if os.stat("databases/db.txt"):#.st_size:
            while flag==1:                                  #runs loop until flag is raised 
                while 1:
                    clear()    
                    u=input("\t\t\tEnter a username:  ")                 #asks for username 
                    if len(u)>1:
                        break
                sf.seek(0)                                 #takes file pointer to beginning
                if os.stat("databases/db.txt").st_size == 0:          #if size of file is zero it does not check for taken usernames
                    break
                hd=hl.sha256(bytes(u,"UTF-8")).hexdigest()  #hash of username
                for line in sf:                                                                       
                    if hd==line.strip():                    #COMPARES hashes of username and db username
                        flag=1
                        print("\t\t\tUsername already exists!!")  #username exists and while loop continues
                        input("\t\t\tPress enter to continue")
                        clear()
                        break
                    else:
                        flag=0                               #while loop is terminated as username is unique
        else:                                                #file could not be opened
            print("\t\t\tError opening database\n")

        while 1:
            pwd1=gp("\t\t\tEnter a strong password(password length(8-15)")
            if len(pwd1)<8 or len(pwd1)>15:
                continue
            pwd2=gp("\t\t\tConfirm the password")
            if pwd1==pwd2 and len(pwd1)>=8 and len(pwd1)<=15:
                break
        print(hl.sha256(bytes(u,"UTF-8")).hexdigest(),file=sf)
        print(hl.sha256(bytes(pwd1,"UTF-8")).hexdigest(),file=sf)
        fname="databases/"+u +".txt"
        with open(fname,"wb") as new:     
            key=Fernet.generate_key()
            new.write(key)
            new.write('\n'.encode('utf-8'))
        input("\t\t\tSuccessfully signed up !!\n\t\t\tPress Enter to continue")
        



