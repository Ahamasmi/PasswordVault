Instructions for using the application:
1.Make sure to have python and pip on your system
2.open command promt/terminal and navigate to the directory where you have installed the application
3.Run the command "pip install -r requirements.txt" in the terminal (without the quotes)
4.Run the Pass_Book Application by double clicking it and use it as you wish to

Made by:
Gopal Pandey
22.05.2019