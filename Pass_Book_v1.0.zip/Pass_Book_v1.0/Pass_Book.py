#saves usernames and passwords of multiple users in encrypted format
#Made by: Gopal Pandey 
# College: IIIT Nagpur 
import functions as fun
import login as lg
from cryptography.fernet import Fernet
from os import system,name
def clear(): 
    if name == 'nt': 
        _ = system('cls')
    else: 
        _ = system('clear') 

while 1:
    clear()
    print("\t\tPass_Book: A password managing software")
    try:
        ch=int(input("\t\t\t1:Login\n\t\t\t2:Signup\n\t\t\t3:Exit\n\t\t\tEnter your choice:   "))
    except ValueError:
        print("\t\t\tInvalid response!")
        input("\t\t\tPress enter to continue")
        continue
    if ch==1:
        #clear()
        user=lg.login()
        print(user)
        if user!="\n" and user!="":                                            #if returned string is non empty
            clear()
            print("\t\t\tAccess Granted!")
            fname="databases/"+user+".txt"                               #name of user specific password database
            while 1:
                ip=int(input("\n\t\t\t1:Retrieve username and password\n\t\t\t2:Add username and password or edit \n\t\t\t3:Print all\n\t\t\t4:Logout\n\t\t\t5:Exit\n\t\t\tEnter your choice:   "))
                if ip==1:                                   #asks for app or website name and spits out uname and password
                    clear()
                    arg=input("\t\t\tWhich application's username and password do you want?\n")
                    fun.search(fname,arg)                   #calls search function from retreive.py
                elif ip==2:                                 #if user wants to edi                                 
                    clear()
                    app=input("\t\t\tEnter application name to add or edit:  ")   #asks for username to search or edit
                    #if ret.research(fname,app)== 1:         #if appname is found then:
                    if fun.research(fname,app)== 1:
                        clear()
                        print("\t\t\tUsername and password for this app already exist")
                        choice=int(input("\t\t\t1:View\n\t\t\t2:Edit\n\t\t\t3:Exit\n\t\t\tEnter your choice:    "))
                        if choice==1:                       #if user asks to view the username and password
                            fun.search(fname,app)
                            continue       
                        elif choice==2:                     #if user asks to edit the current credentials
                            fun.change(fname,app)
                            continue
                        else:                               #if users wants to exit
                            continue                       
                    uname=input("\t\t\tEnter username:    ")         #asking user for username if no matches were found
                    pwd=input("\t\t\tEnter password:    ")           #asking user for password
                    fun.add(fname,app,uname,pwd)           #adding the entry to the file
                elif ip==3:
                    fun.disp(fname)
                elif ip==4:
                    break
                elif ip==5:
                    exit()
        elif user=="\n":
            pass
        else:                                               #if returned string is empty ie. credentials did not match
            print("\t\t\tWrong Credentials!")
            input("\t\t\tPress Enter to continue")
        
    elif ch==2:                                             #if user wants to signup
        lg.signup()
    elif ch==3:                                             #if user wants to exit
        break  



